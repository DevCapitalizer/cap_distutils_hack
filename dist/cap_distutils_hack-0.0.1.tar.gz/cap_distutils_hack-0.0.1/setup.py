from setuptools import find_packages, setup


setup(
    name="cap_distutils_hack",
    version="0.0.1",
    description="None",
    # package_dir={"": "_distutils_hack"},
    packages=['cap_distutils_hack'],
    long_description='Long long',
    long_description_content_type="text/markdown",
    url="https://github.com/DevCapitalizer/cap_distutils_hack",
    author="DDjango",
    author_email="ddjango.786@gmail.com",
    license="MIT",
    # classifiers=[
    #     "License :: OSI Approved :: MIT License",
    #     "Programming Language :: Python :: 3.9",
    #     "Operating System :: OS Independent",
    # ],
    python_requires=">=3.9",
)